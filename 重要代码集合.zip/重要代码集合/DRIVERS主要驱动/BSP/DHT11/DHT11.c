#include "DHT11.h"
#include "stm32f4xx_hal.h"

#define DHT11_PORT GPIOC
#define DHT11_PIN  GPIO_PIN_10

// ???????(?? DWT)
static void Delay_us(uint32_t us)
{
    uint32_t startTick = DWT->CYCCNT;
    uint32_t delayTicks = us * (SystemCoreClock / 1000000);
    while ((DWT->CYCCNT - startTick) < delayTicks);
}

void DHT11_Init(void)
{
    // ?? GPIOC ??
    __HAL_RCC_GPIOC_CLK_ENABLE();

    // ?? DWT ???
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;

    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin = DHT11_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(DHT11_PORT, &GPIO_InitStruct);

    HAL_GPIO_WritePin(DHT11_PORT, DHT11_PIN, GPIO_PIN_SET);
}

static void DHT11_Start(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin = DHT11_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(DHT11_PORT, &GPIO_InitStruct);

    HAL_GPIO_WritePin(DHT11_PORT, DHT11_PIN, GPIO_PIN_RESET);
    HAL_Delay(20);
    HAL_GPIO_WritePin(DHT11_PORT, DHT11_PIN, GPIO_PIN_SET);
    Delay_us(30);

    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    HAL_GPIO_Init(DHT11_PORT, &GPIO_InitStruct);
}

static uint8_t DHT11_Check_Response(void)
{
    uint8_t retry = 0;
    while (HAL_GPIO_ReadPin(DHT11_PORT, DHT11_PIN) == GPIO_PIN_SET)
    {
        if (++retry > 100) return 1;
        Delay_us(1);
    }

    retry = 0;
    while (HAL_GPIO_ReadPin(DHT11_PORT, DHT11_PIN) == GPIO_PIN_RESET)
    {
        if (++retry > 100) return 1;
        Delay_us(1);
    }

    retry = 0;
    while (HAL_GPIO_ReadPin(DHT11_PORT, DHT11_PIN) == GPIO_PIN_SET)
    {
        if (++retry > 100) return 1;
        Delay_us(1);
    }

    return 0;
}

static uint8_t DHT11_Read_Bit(void)
{
    uint32_t t = 0;

    // ???????
    while (HAL_GPIO_ReadPin(DHT11_PORT, DHT11_PIN) == GPIO_PIN_RESET)
    {
        t++;
        Delay_us(1);
        if (t > 100) return 0; // ????
    }

    t = 0;
    // ?????????
    while (HAL_GPIO_ReadPin(DHT11_PORT, DHT11_PIN) == GPIO_PIN_SET)
    {
        t++;
        Delay_us(1);
        if (t > 100) break;
    }

    // ?? >40us ? 1,<40us ? 0
    return (t > 40) ? 1 : 0;
}

static uint8_t DHT11_Read_Byte(void)
{
    uint8_t i, data = 0;
    for (i = 0; i < 8; i++)
    {
        data <<= 1;
        data |= DHT11_Read_Bit();
    }
    return data;
}
uint8_t humi_int, humi_dec, temp_int, temp_dec, checksum;

uint8_t DHT11_Read_Data(uint8_t *temperature, uint8_t *humidity)
{
    

    DHT11_Start();

    if (DHT11_Check_Response()) return 1;

    humi_int = DHT11_Read_Byte();
    humi_dec = DHT11_Read_Byte();
    temp_int = DHT11_Read_Byte();
    temp_dec = DHT11_Read_Byte();
    checksum = DHT11_Read_Byte();

//    if (checksum != (humi_int + humi_dec + temp_int + temp_dec)) return 2;

    *humidity = humi_int;
    *temperature = temp_int;

    return 0;
}

