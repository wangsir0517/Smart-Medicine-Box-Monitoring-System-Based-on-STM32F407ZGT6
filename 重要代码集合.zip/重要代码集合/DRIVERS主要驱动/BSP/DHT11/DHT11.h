
#ifndef __DHT11_H
#define __DHT11_H

#include "stm32f4xx_hal.h"

// DHT11???GPIO???(??????)
#define DHT11_GPIO_Port GPIOC
#define DHT11_Pin       GPIO_PIN_10
typedef uint8_t u8;
void DHT11_Init(void);
uint8_t DHT11_Read_Data(uint8_t *temperature, uint8_t *humidity);
// DHT11.h




u8 DHT11_Read_Data(u8 *temp, u8 *humi);

#endif

