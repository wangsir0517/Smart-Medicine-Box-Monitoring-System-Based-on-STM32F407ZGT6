#ifndef __HX711_H
#define __HX711_H

#include "stm32f4xx_hal.h"
#include "./SYSTEM/sys/sys.h"
#include "./SYSTEM/delay/delay.h"  // ? ???? delay_us ? DWT_Init ????

// HX711 ????
#define HX711_SCK_PORT      GPIOC
#define HX711_SCK_PIN       GPIO_PIN_6
#define HX711_DT_PORT       GPIOC
#define HX711_DT_PIN        GPIO_PIN_7

// ?????
#define HX711_SCK_HIGH()    HAL_GPIO_WritePin(HX711_SCK_PORT, HX711_SCK_PIN, GPIO_PIN_SET)
#define HX711_SCK_LOW()     HAL_GPIO_WritePin(HX711_SCK_PORT, HX711_SCK_PIN, GPIO_PIN_RESET)
#define HX711_DT_READ()     HAL_GPIO_ReadPin(HX711_DT_PORT, HX711_DT_PIN)

// ????
void HX711_Init(void);
int32_t HX711_GetData(void);

#endif /* __HX711_H */
