#include "DHT11.h"
#include "HX711.h"





void HX711_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    __HAL_RCC_GPIOC_CLK_ENABLE();

    // ?? SCK ???
    GPIO_InitStruct.Pin = HX711_SCK_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(HX711_SCK_PORT, &GPIO_InitStruct);

    // ?? DT ?????
    GPIO_InitStruct.Pin = HX711_DT_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    HAL_GPIO_Init(HX711_DT_PORT, &GPIO_InitStruct);

    HX711_SCK_LOW();
}

// ??????????(???,?????)
int32_t HX711_GetData(void)
{
    uint32_t Count = 0;
    uint8_t i;
    uint32_t timeout = 100000;

    HX711_SCK_LOW();
    delay_us(1);

    // ?? DT ??,???????(?????)
    while (HX711_DT_READ() == GPIO_PIN_SET)
    {
        if (--timeout == 0)
        {
            return 0x80000000; // ???
        }
        delay_us(1);
    }

    // ?? 24 ???
    for (i = 0; i < 24; i++)
    {
        HX711_SCK_HIGH();
        delay_us(1);

        Count <<= 1;

        HX711_SCK_LOW();
        delay_us(1);

        if (HX711_DT_READ() == GPIO_PIN_SET)
        {
            Count++;
        }
    }

    // ?25???:???????(??128?,A??)
    HX711_SCK_HIGH();
    delay_us(1);
    HX711_SCK_LOW();
    delay_us(1);

    // ?????(24??32?)
    if (Count & 0x800000)
    {
        Count |= 0xFF000000;
    }

    return (int32_t)Count;
}
