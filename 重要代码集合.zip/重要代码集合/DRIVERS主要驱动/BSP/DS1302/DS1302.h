#ifndef __DS1302_H
#define __DS1302_H

#include "./SYSTEM/sys/sys.h"

/********************** ???? **********************/
void DS1302_Init(void);
void DS1302_SetTime(uint8_t hour, uint8_t min, uint8_t sec);
void DS1302_GetTime(uint8_t *hour, uint8_t *min, uint8_t *sec);
void DS1302_GetDate(uint8_t *year, uint8_t *month, uint8_t *day);
void DS1302_SetDate(uint8_t year, uint8_t month, uint8_t day);

#endif
