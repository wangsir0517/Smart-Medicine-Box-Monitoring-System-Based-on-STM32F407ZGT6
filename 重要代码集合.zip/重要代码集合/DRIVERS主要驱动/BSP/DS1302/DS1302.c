#include "DS1302.h"
#include "delay.h"

/* === DS1302 ???? === */
#define DS1302_CE_PORT    GPIOA
#define DS1302_CE_PIN     GPIO_PIN_3

#define DS1302_SCLK_PORT  GPIOA
#define DS1302_SCLK_PIN   GPIO_PIN_4

#define DS1302_IO_PORT    GPIOA
#define DS1302_IO_PIN     GPIO_PIN_5

/* === DS1302 ????? === */
#define DS1302_SECONDS    0x80
#define DS1302_MINUTES    0x82
#define DS1302_HOUR       0x84
#define DS1302_WP         0x8E

/* === BCD ??? === */
#define BCD2DEC(bcd)   (((bcd) >> 4) * 10 + ((bcd) & 0x0F))
#define DEC2BCD(dec)   ((((dec) / 10) << 4) | ((dec) % 10))

/* === IO ???? === */
static void DS1302_IO_IN(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin = DS1302_IO_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    HAL_GPIO_Init(DS1302_IO_PORT, &GPIO_InitStruct);
}

static void DS1302_IO_OUT(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin = DS1302_IO_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(DS1302_IO_PORT, &GPIO_InitStruct);
}

/* === ??? DS1302 ?? === */
void DS1302_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    __HAL_RCC_GPIOA_CLK_ENABLE();

    // CE ??
    GPIO_InitStruct.Pin = DS1302_CE_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(DS1302_CE_PORT, &GPIO_InitStruct);

    // SCLK ??
    GPIO_InitStruct.Pin = DS1302_SCLK_PIN;
    HAL_GPIO_Init(DS1302_SCLK_PORT, &GPIO_InitStruct);

    // IO ??
    GPIO_InitStruct.Pin = DS1302_IO_PIN;
    HAL_GPIO_Init(DS1302_IO_PORT, &GPIO_InitStruct);

    // ????????
    HAL_GPIO_WritePin(DS1302_CE_PORT, DS1302_CE_PIN, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(DS1302_SCLK_PORT, DS1302_SCLK_PIN, GPIO_PIN_RESET);
}

/* === ? DS1302 ????? === */
static void DS1302_WriteByte(uint8_t data)
{
    DS1302_IO_OUT();
    for (uint8_t i = 0; i < 8; i++)
    {
        HAL_GPIO_WritePin(DS1302_IO_PORT, DS1302_IO_PIN, (data & (1 << i)) ? GPIO_PIN_SET : GPIO_PIN_RESET);
        HAL_GPIO_WritePin(DS1302_SCLK_PORT, DS1302_SCLK_PIN, GPIO_PIN_SET);
        HAL_Delay(1);
        HAL_GPIO_WritePin(DS1302_SCLK_PORT, DS1302_SCLK_PIN, GPIO_PIN_RESET);
    }
}

/* === ? DS1302 ????? === */
static uint8_t DS1302_ReadByte(void)
{
    uint8_t data = 0;
    DS1302_IO_IN();

    for (uint8_t i = 0; i < 8; i++)
    {
        HAL_GPIO_WritePin(DS1302_SCLK_PORT, DS1302_SCLK_PIN, GPIO_PIN_SET);
        HAL_Delay(1);
        if (HAL_GPIO_ReadPin(DS1302_IO_PORT, DS1302_IO_PIN))
            data |= (1 << i);
        HAL_GPIO_WritePin(DS1302_SCLK_PORT, DS1302_SCLK_PIN, GPIO_PIN_RESET);
    }
    return data;
}

/* === ???? === */
static void DS1302_WriteReg(uint8_t reg, uint8_t value)
{
    HAL_GPIO_WritePin(DS1302_CE_PORT, DS1302_CE_PIN, GPIO_PIN_SET);
    DS1302_WriteByte(reg);
    DS1302_WriteByte(value);
    HAL_GPIO_WritePin(DS1302_CE_PORT, DS1302_CE_PIN, GPIO_PIN_RESET);
}

/* === ???? === */
static uint8_t DS1302_ReadReg(uint8_t reg)
{
    uint8_t value;
    HAL_GPIO_WritePin(DS1302_CE_PORT, DS1302_CE_PIN, GPIO_PIN_SET);
    DS1302_WriteByte(reg | 0x01);
    value = DS1302_ReadByte();
    HAL_GPIO_WritePin(DS1302_CE_PORT, DS1302_CE_PIN, GPIO_PIN_RESET);
    return value;
}

/* === ???? === */
void DS1302_SetTime(uint8_t hour, uint8_t min, uint8_t sec)
{
    DS1302_WriteReg(DS1302_WP, 0x00);  // ?????
    DS1302_WriteReg(DS1302_SECONDS, DEC2BCD(sec) & 0x7F);  // ?,????CH,?????1
    DS1302_WriteReg(DS1302_MINUTES, DEC2BCD(min));
    DS1302_WriteReg(DS1302_HOUR, DEC2BCD(hour));
    DS1302_WriteReg(DS1302_WP, 0x80);  // ?????
}

/* === ???? === */
void DS1302_GetTime(uint8_t *hour, uint8_t *min, uint8_t *sec)
{
    *sec = BCD2DEC(DS1302_ReadReg(DS1302_SECONDS) & 0x7F);
    *min = BCD2DEC(DS1302_ReadReg(DS1302_MINUTES));
    *hour = BCD2DEC(DS1302_ReadReg(DS1302_HOUR));
}
