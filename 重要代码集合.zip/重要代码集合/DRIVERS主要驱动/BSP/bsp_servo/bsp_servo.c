#include "bsp_servo.h"

// ????????
TIM_HandleTypeDef TIM1_Handler;
TIM_OC_InitTypeDef TIM1_CH1Handler;

// ?????(TIM1_CH1 ? PA8)
void Servo_Init(uint16_t arr, uint16_t psc)
{
    GPIO_InitTypeDef GPIO_Initure;

    __HAL_RCC_TIM1_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();

    // PA8 ??? TIM1_CH1
    GPIO_Initure.Pin = GPIO_PIN_8;
    GPIO_Initure.Mode = GPIO_MODE_AF_PP;
    GPIO_Initure.Pull = GPIO_NOPULL;
    GPIO_Initure.Speed = GPIO_SPEED_FREQ_HIGH;
    GPIO_Initure.Alternate = GPIO_AF1_TIM1;
    HAL_GPIO_Init(GPIOA, &GPIO_Initure);

    // TIM1 ????
    TIM1_Handler.Instance = TIM1;
    TIM1_Handler.Init.Prescaler = psc;
    TIM1_Handler.Init.CounterMode = TIM_COUNTERMODE_UP;
    TIM1_Handler.Init.Period = arr;
    TIM1_Handler.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
    HAL_TIM_PWM_Init(&TIM1_Handler);

    // ?? PWM ????
    TIM1_CH1Handler.OCMode = TIM_OCMODE_PWM1;
    TIM1_CH1Handler.Pulse = 1500;  // ??????
    TIM1_CH1Handler.OCPolarity = TIM_OCPOLARITY_HIGH;
    TIM1_CH1Handler.OCFastMode = TIM_OCFAST_DISABLE;
    HAL_TIM_PWM_ConfigChannel(&TIM1_Handler, &TIM1_CH1Handler, TIM_CHANNEL_1);

    // ?? PWM
    HAL_TIM_PWM_Start(&TIM1_Handler, TIM_CHANNEL_1);
}

// ??????(0~180�)
//open 50;close 15
void SG90_SetAngle(uint8_t angle)
{
		TIM1->CCR1 = 100*angle;
}

