#ifndef __BSP_SERVO_H
#define __BSP_SERVO_H

#include "stm32f4xx_hal.h"

#ifdef __cplusplus
extern "C" {
#endif

void Servo_Init(uint16_t arr, uint16_t psc);
void SG90_SetAngle(uint8_t angle);

#ifdef __cplusplus
}
#endif

#endif
