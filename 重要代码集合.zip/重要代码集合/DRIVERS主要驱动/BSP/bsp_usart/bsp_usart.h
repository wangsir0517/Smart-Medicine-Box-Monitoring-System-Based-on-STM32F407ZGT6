#ifndef __BSP_USART_H
#define __BSP_USART_H

#include "stm32f4xx_hal.h"

extern UART_HandleTypeDef huart2;

void HC05_UART_Init(void);
void HC05_SendString(char *str);
uint8_t HC05_ReceiveByte(uint8_t *data);

#endif
