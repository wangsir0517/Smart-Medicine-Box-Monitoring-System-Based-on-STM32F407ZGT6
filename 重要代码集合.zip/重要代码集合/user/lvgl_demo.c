/**
 ****************************************************************************************************
 * @file        lvgl_demo.c
 * @author      ����ԭ���Ŷ�(ALIENTEK)
 * @version     V1.0
 * @date        2022-01-11
 * @brief       LVGL lv_btn(��ť) ʵ��
 * @license     Copyright (c) 2020-2032, �������������ӿƼ����޹�˾
 ****************************************************************************************************
 * @attention
 *
 * ʵ��ƽ̨:����ԭ�� ̽���� F407������
 * ������Ƶ:www.yuanzige.com
 * ������̳:www.openedv.com
 * ��˾��ַ:www.alientek.com
 * �����ַ:openedv.taobao.com
 *
 ****************************************************************************************************
 */
 
#include "lvgl_demo.h"
#include "./BSP/LED/led.h"
#include "FreeRTOS.h"
#include "task.h"
#include "lvgl.h"
#include "lv_port_disp_template.h"
#include "lv_port_indev_template.h"
#include "LVGL/GUI_APP/lv_mainstart.h"
#include "DS1302.h"
#include "./BSP/LCD/lcd.h"
#include "gui_guider.h"
#include "./BSP/TIMER/btim.h"
#include "DHT11.h"
#include "HX711.h"
#include "bsp_servo.h"
#include "max30102.h"
#include "semphr.h"
#include "lv_conf.h"
#include "./SYSTEM/sys/sys.h"
#include "delay.h"
#include "bsp_usart.h"
#include "./SYSTEM/usart/usart.h"
#include "./BSP/LED/led.h"
#define MAX_BRIGHTNESS 255
#define PBin(n)  (*(volatile uint32_t *)(0x42000000 + ((uint32_t)&GPIOB->IDR - 0x40000000)*32 + (n)*4))

/* FreeRTOS ?????????? */
#define START_TASK_PRIO     1
#define START_STK_SIZE      128
TaskHandle_t StartTask_Handler;
void start_task(void *pvParameters);

#define LV_DEMO_TASK_PRIO   3
#define LV_DEMO_STK_SIZE    1024
TaskHandle_t LV_DEMOTask_Handler;
void lv_demo_task(void *pvParameters);

#define LED_TASK_PRIO       4
#define LED_STK_SIZE        128
TaskHandle_t LEDTask_Handler;
void led_task(void *pvParameters);

#define SERVO_TASK_PRIO     2
#define SERVO_STK_SIZE      128
TaskHandle_t ServoTask_Handler;
void servo_task(void *pvParameters);
#define MAX30102_TASK_PRIO   5
#define MAX30102_STK_SIZE    256
TaskHandle_t Max30102Task_Handler;
void max30102_task(void *pvParameters);

/**
 * @brief       lvgl_demo ?????
 */
void lvgl_demo(void)
{
    lv_init();
    lv_port_disp_init();
    lv_port_indev_init();

    xTaskCreate(start_task, "start_task", START_STK_SIZE, NULL, START_TASK_PRIO, &StartTask_Handler);

    vTaskStartScheduler();
}

/**
 * @brief       ???????
 */
void start_task(void *pvParameters)
{
//	DS1302_SetTime(0, 0, 0); // ??????:12:00:00

    (void)pvParameters;
    taskENTER_CRITICAL();

    DS1302_Init();

    // ??? SG90 ??:20ms ??,1MHz ??
//    Servo_Init(20000 - 1, 84 - 1);
//    SG90_SetAngle(90); // ????? 90�

    xTaskCreate(lv_demo_task, "lv_demo_task", LV_DEMO_STK_SIZE, NULL, LV_DEMO_TASK_PRIO, &LV_DEMOTask_Handler);
    xTaskCreate(led_task, "led_task", LED_STK_SIZE, NULL, LED_TASK_PRIO, &LEDTask_Handler);
    xTaskCreate(servo_task, "servo_task", SERVO_STK_SIZE, NULL, SERVO_TASK_PRIO, &ServoTask_Handler);
    xTaskCreate(max30102_task, "max30102_task", MAX30102_STK_SIZE, NULL, MAX30102_TASK_PRIO, &Max30102Task_Handler);

    taskEXIT_CRITICAL();
    vTaskDelete(StartTask_Handler);
}
void max30102_task(void *pvParameters)
{
    (void)pvParameters;

    uint32_t aun_ir_buffer[500]; // IR????
    uint32_t aun_red_buffer[500]; // ??????
    int32_t n_sp02, n_heart_rate;
    int8_t ch_spo2_valid, ch_hr_valid;
    uint8_t temp[6];
    uint32_t un_min, un_max, un_prev_data;
    float f_temp;
    int n_brightness = 0;
    int i;

    MAX30102_Init();
    vTaskDelay(pdMS_TO_TICKS(500));

    // ?????
    un_min = 0x3FFFF;
    un_max = 0;

    // ????500???
    for (i = 0; i < 500; i++)
    {
        while (MAX30102_INT == 1);
        max30102_FIFO_ReadBytes(REG_FIFO_DATA, temp);
        aun_red_buffer[i] = ((uint32_t)(temp[0] & 0x03) << 16) | (uint32_t)(temp[1] << 8) | temp[2];
        aun_ir_buffer[i]  = ((uint32_t)(temp[3] & 0x03) << 16) | (uint32_t)(temp[4] << 8) | temp[5];

        if (un_min > aun_red_buffer[i]) un_min = aun_red_buffer[i];
        if (un_max < aun_red_buffer[i]) un_max = aun_red_buffer[i];
    }

    // ?????????
    maxim_heart_rate_and_oxygen_saturation(
        aun_ir_buffer, 500,
        aun_red_buffer,
        &n_sp02, &ch_spo2_valid,
        &n_heart_rate, &ch_hr_valid
    );

    while (1)
    {
        // ?400-499??????0-99
        for (i = 100; i < 500; i++)
        {
            aun_red_buffer[i - 100] = aun_red_buffer[i];
            aun_ir_buffer[i - 100] = aun_ir_buffer[i];

            if (un_min > aun_red_buffer[i]) un_min = aun_red_buffer[i];
            if (un_max < aun_red_buffer[i]) un_max = aun_red_buffer[i];
        }

        // ???100???
        for (i = 400; i < 500; i++)
        {
            un_prev_data = aun_red_buffer[i - 1];

            while (MAX30102_INT == 1);
            max30102_FIFO_ReadBytes(REG_FIFO_DATA, temp);

            aun_red_buffer[i] = ((uint32_t)(temp[0] & 0x03) << 16) | (uint32_t)(temp[1] << 8) | temp[2];
            aun_ir_buffer[i]  = ((uint32_t)(temp[3] & 0x03) << 16) | (uint32_t)(temp[4] << 8) | temp[5];

            // ??????(???)
            if (aun_red_buffer[i] > un_prev_data)
            {
                f_temp = (float)(aun_red_buffer[i] - un_prev_data) / (un_max - un_min);
                f_temp *= MAX_BRIGHTNESS;
                n_brightness -= (int)f_temp;
                if (n_brightness < 0) n_brightness = 0;
            }
            else
            {
                f_temp = (float)(un_prev_data - aun_red_buffer[i]) / (un_max - un_min);
                f_temp *= MAX_BRIGHTNESS;
                n_brightness += (int)f_temp;
                if (n_brightness > MAX_BRIGHTNESS) n_brightness = MAX_BRIGHTNESS;
            }
        }

        // ??????
        maxim_heart_rate_and_oxygen_saturation(
            aun_ir_buffer, 500,
            aun_red_buffer,
            &n_sp02, &ch_spo2_valid,
            &n_heart_rate, &ch_hr_valid
        );

        // ????
        if (ch_hr_valid == 1 && n_heart_rate < 120)
        {
            printf("?? = %d BPM, ?? = %d%%\r\n", n_heart_rate, n_sp02);
        }
        else
        {
            printf("wrong\r\n");
        }

        // ??????:??500ms~1s
        vTaskDelay(pdMS_TO_TICKS(500));
    }
}

/**
 * @brief       SG90 ??????
 */
void servo_task(void *pvParameters)
{
    (void)pvParameters;
    while (1)
    {
			 SG90_SetAngle(15);
        vTaskDelay(2000);
//        SG90_SetAngle(35);
//        vTaskDelay(2000);
        
    }
}

/**
 * @brief       LVGL ????
 */
extern lv_ui guider_ui;
extern uint8_t A1;
int32_t reset = 0;
int value = 0;
float weight = 0;

float Weights = 100.0;       // 100g
int32_t Weights_100 = 8493860;  // 100g ???
extern uint16_t rec_dat[5];
extern uint8_t g_rx_buffer[RXBUFFERSIZE];
extern TIM_HandleTypeDef TIM1_Handler;
uint8_t i3 = 0;
uint8_t res = 0;
uint8_t temp = 0, hum = 0;

void lv_demo_task(void *pvParameters)
{
    (void)pvParameters;

    setup_ui(&guider_ui);
    HX711_Init();
    DHT11_Init();
    reset = HX711_GetData();

    uint8_t hour = 0, min = 0, sec = 0;
    int rtc_counter = 0;
      

    while (1)
    {
     
        value = HX711_GetData();
        weight = (float)(value - reset) / 100;
			if (weight < 0) weight = 0;
        lcd_show_num(-20, 30, weight, 16, 16, BLACK);

        if (weight < 2) {
            // ?????????????
        }

        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_9, GPIO_PIN_SET);


	res = DHT11_Read_Data(&temp, &hum);
//				temp = temp+25;
//				hum = hum-20;
//        printf("Temp: %d Hum: %d%%\r\n", temp, hum);
lcd_show_num(10, 50, res, 1, 16, RED);  // ?????

if (res == 0) {
    lcd_show_num(10, 100, temp, 2, 16, BLACK);
    lcd_show_num(10, 120, hum, 2, 16, BLACK);
} else {
//    lcd_show_num(10, 100, 0000,2, 16,BLACK);
}



        /* DS1302 ???? */
              /* ?????????? */
        rtc_counter++;
        if (rtc_counter >= 10)
{
    rtc_counter = 0;

    // ?????(????while????,???????)
    res = DHT11_Read_Data(&temp, &hum);

    // ????
    DS1302_GetTime(&hour, &min, &sec);

    // ????:??
    printf("Time: %02d:%02d:%02d\r\n", hour, min, sec);

    // ????:??
    printf("Weight: %.1fg\r\n", weight);
    printf("Temp: %d Hum: %d%%\r\n", temp, hum);


    // LCD ????
    lcd_show_num(-20, 160, hour, 16, 16, BLACK);
    lcd_show_num(-20, 180, min, 16, 16, BLACK);
    lcd_show_num(-20, 200, sec, 16, 16, BLACK);
}



        lv_timer_handler();
        vTaskDelay(100);
    }
}





/**
 * @brief       LED ??
 */
uint8_t ir = 0;
uint8_t k0 = 0;
uint8_t k1 = 0;

void led_task(void *pvParameters)
{
    (void)pvParameters;
       
    while (1)
    {
        ir = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_1);
        k0 = HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_4);
        k1 = HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_3);
//        if (ir == 1) {
//            LED1(0);	 
//        } else {
//            LED1(1);
//					delay_ms(500);
//				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15, GPIO_PIN_RESET);
//        }
				LED0_TOGGLE();
				LED1_TOGGLE();
        vTaskDelay(1500);
    }
}

