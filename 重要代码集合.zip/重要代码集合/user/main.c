/**
 ****************************************************************************************************
 * @file        main.c
 * @author      ����ԭ���Ŷ�(ALIENTEK)
 * @version     V1.0
 * @date        2020-04-28
 * @brief       LVGL lv_btn(��ť) ʵ��
 * @license     Copyright (c) 2020-2032, �������������ӿƼ����޹�˾
 ****************************************************************************************************
 * @attention
 *
 * ʵ��ƽ̨:����ԭ�� ̽���� F407������
 * ������Ƶ:www.yuanzige.com
 * ������̳:www.openedv.com
 * ��˾��ַ:www.alientek.com
 * �����ַ:openedv.taobao.com
 *
 ****************************************************************************************************
 */

#include "./SYSTEM/sys/sys.h"
#include "./SYSTEM/usart/usart.h"
#include "./SYSTEM/delay/delay.h"
#include "./BSP/LED/led.h"
#include "./BSP/KEY/key.h"
#include "./BSP/SRAM/sram.h"
#include "./MALLOC/malloc.h"
#include "./BSP/TOUCH/touch.h"
#include "lvgl_demo.h"
#include "DS1302.h"
#include "./BSP/LCD/lcd.h"
#include "./BSP/TIMER/btim.h"
#include "DHT11.h"
#include "HX711.h"
#include "bsp_servo.h"
#include "bsp_usart.h"     // <<< ?? HC05 usart ????

int main(void)
{
    HAL_Init();      // ???HAL?                    
    sys_stm32_clock_init(336, 8, 2, 7); /* ????,168Mhz */
    
    delay_init(168);  /* ????? */                  
    usart_init(9600);                    /* ??????9600 */

    led_init();                         
    key_init();                         
    sram_init();                       /* ???SRAM */  
    tp_dev.init();                       /* ????? */
    lcd_init();                        
    my_mem_init(SRAMIN);                 /* ???SRAM?? */
    my_mem_init(SRAMEX);                 /* ?????SRAM?? */

    TIM3_Init(5000 - 1, 8400 - 1);       // ??????3,500ms??
    Servo_Init(20000 - 1, 84 - 1);     	// ?????

    DS1302_Init();                      // ???DS1302??
    DHT11_Init();                       // ???DHT11?????
    HX711_Init();                       // ???HX711?????

    HC05_UART_Init();                   // ???HC05????
    HC05_SendString("Welcome to use the intelligent medicine box system\r\n");

    uint8_t rx;
    if (HC05_ReceiveByte(&rx) == HAL_OK)
    {
        // ??HC05??????
//        if (rx == '1') SG90_SetAngle(0);      // '1' -> ??0?
//        else if (rx == '2') SG90_SetAngle(90); // '2' -> ??90?
//        else if (rx == '3') SG90_SetAngle(180);// '3' -> ??180?
    }

    // ????????
//    xTaskCreate(HeartRateMonitorTask, "HeartRateMonitorTask", 512, NULL, 1, NULL);
//    
//    // ??FreeRTOS???
//    vTaskStartScheduler();
    
    // ?????????,?????????
    while(1);
}

